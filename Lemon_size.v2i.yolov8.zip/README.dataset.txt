# Lemon_size > 2026-02-23 10:47pm
https://universe.roboflow.com/lemonmodel-klqv6/lemon_size-ucegv

Provided by a Roboflow user
License: CC BY 4.0

